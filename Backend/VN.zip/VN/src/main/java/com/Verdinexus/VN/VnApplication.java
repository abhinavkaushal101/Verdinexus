package com.Verdinexus.VN;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VnApplication {

	public static void main(String[] args) {
		SpringApplication.run(VnApplication.class, args);
	}

}
